declare module "graphql-tag" {
  const gql: (template: TemplateStringsArray | string) => any;
  export default gql;
}
